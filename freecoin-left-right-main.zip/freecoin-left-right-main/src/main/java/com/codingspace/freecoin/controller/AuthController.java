package com.codingspace.freecoin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.codingspace.freecoin.model.Auth;
import com.codingspace.freecoin.model.User;
import com.codingspace.freecoin.model.reqres.AuthValidateReq;
import com.codingspace.freecoin.model.reqres.AuthValidateRes;
import com.codingspace.freecoin.model.reqres.ChangePasswordReq;
import com.codingspace.freecoin.repository.AuthRepository;
import com.codingspace.freecoin.repository.UserRepository;
import com.codingspace.freecoin.repository.AuthRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    AuthRepository authRepository;

    @Autowired
    UserRepository userRepository;

    @PostMapping("/validate")
    public ResponseEntity<Map<String, Object>> validate(@RequestBody AuthValidateReq reqBody) {
        Boolean isAuth;
        User user = userRepository.getByRefId(reqBody.getRefId());
        Map<String, Object> response = new HashMap<String, Object>();

        if (user == null) {
            isAuth = false;
        } else {
            isAuth = authRepository.validate(user.getId(), reqBody.getPassword());
        }

        response.put("isAuth", isAuth);
        if (isAuth) {
            User token = user;
            response.put("token", token);
            return ResponseEntity.ok().body(response);
        } else {
            return ResponseEntity.ok().body(response);
        }
    }

    @PostMapping("/changePassword")
    public Boolean changePassword(@RequestBody ChangePasswordReq changePasswordReq) {

        Auth response = authRepository.changePassword(changePasswordReq.getUserId(), changePasswordReq.getOldPassword(),
                changePasswordReq.getNewPassword());

        return response != null;
    }

    @GetMapping("/allAuthList")
    public List<Auth> getAll() {
        return authRepository.getAllAuthList();
    }
}
